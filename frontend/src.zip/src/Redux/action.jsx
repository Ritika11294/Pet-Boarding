//action
export const GET_DATA = "GET_DATA";

//dispatch
export const addData = (value) => ({type: GET_DATA, payload: value});